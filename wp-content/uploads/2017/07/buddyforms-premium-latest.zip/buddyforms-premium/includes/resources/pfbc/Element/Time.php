<?php

/**
 * Class Element_Time
 */
class Element_Time extends Element_Textbox {
	/**
	 * @var array
	 */
	protected $_attributes = array( "type" => "time" );
}
