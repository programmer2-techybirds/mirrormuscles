<?php

/**
 * Class Element_Password
 */
class Element_Password extends Element_Textbox {
	/**
	 * @var array
	 */
	protected $_attributes = array( "type" => "password" );
}
