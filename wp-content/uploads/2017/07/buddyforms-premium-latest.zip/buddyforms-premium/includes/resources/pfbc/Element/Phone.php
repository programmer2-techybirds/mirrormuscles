<?php

/**
 * Class Element_Phone
 */
class Element_Phone extends Element_Textbox {
	/**
	 * @var array
	 */
	protected $_attributes = array( "type" => "tel" );
}
