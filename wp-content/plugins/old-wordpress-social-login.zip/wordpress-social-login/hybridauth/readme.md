#### INORMATION

This is a heavily edited fork of the HybridAuth library and no longer compatible with the master branch.
