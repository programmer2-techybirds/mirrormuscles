===================================================
 Installation Steps - WordPress CometChat Plugin
===================================================

1. Upload the extracted files to your WordPress root folder (assuming WordPress is present at http://www.yoursite.com/wordpress henceforth)

Directory structure

- COMETCHAT_UNZIP_FIRST
	- cometchat.zip
	- wordpress.zip
	- README.pdf

2. Now login to your wordpress admin panel.

- Goto Plugins > Add New > Upload Plugin

3. Upload your wordpress.zip

4. You will receive “Plugin installed successfully” message. Now click on Activate plugin and navigate to CometChat menu.

5. Click “Choose File” and choose cometchat.zip and click Install Now.

6. CometChat is now installed on your website!

================================
 CometChat Administration Panel
================================

1. CometChat Admin Panel can be accessed at wordpress dashboard.

===============================
 CometChat Additional setting
===============================

1. Click on "Hide CometChat for which usergroups?" to hide CometChat bar for different user roles.

2. Click on 'Yes' in "Enable Inbox Synchronization" to activate to inbox synchronization.

2. Click on 'Yes' in "Hide CometChat bar?" to hide CometChat bar from your site.


