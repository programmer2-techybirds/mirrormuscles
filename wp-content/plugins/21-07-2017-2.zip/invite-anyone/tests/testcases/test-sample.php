<?php

class Invite_Anyone_Tests extends BP_UnitTestCase {

	/**
	 * @group invite_anyone_group_invite_access_test
	 */
	public function test_group_access_test_no_group() {
		$this->assertSame( 'noone', invite_anyone_group_invite_access_test() );
	}

	/**
	 * @group invite_anyone_group_invite_access_test
	 */
	public function test_group_access_test_no_group_during_group_creation() {
		$cc = bp_current_component();
		$ca = bp_current_action();
		buddypress()->current_component = buddypress()->groups->id;
		buddypress()->current_action = 'create';

		$u = $this->factory->user->create();
		$this->assertSame( 'anyone', invite_anyone_group_invite_access_test( 0, $u ) );

		buddypress()->current_component = $cc;
		buddypress()->current_action = $ca;
	}

	/**
	 * @group invite_anyone_group_invite_access_test
	 */
	public function test_group_access_test_logged_out() {
		$old_current_user = get_current_user_id();
		$this->set_current_user( 0 );

		$g = $this->factory->group->create();

		$this->assertSame( 'noone', invite_anyone_group_invite_access_test( $g ) );

		$this->set_current_user( $old_current_user );
	}

	/**
	 * @group invite_anyone_group_invite_access_test
	 */
	public function test_group_access_test_not_a_member_of_group() {
		$u = $this->factory->user->create();
		$g = $this->factory->group->create();

		$this->assertSame( 'noone', invite_anyone_group_invite_access_test( $g, $u ) );
	}

	/**
	 * @group invite_anyone_group_invite_access_test
	 *
	 * Using this as a proxy for testing every possible combination
	 */
	public function test_group_access_test_friends() {
		$settings = bp_get_option( 'invite_anyone' );
		bp_update_option( 'invite_anyone', array(
			'group_invites_can_admin' => 'friends',
			'group_invites_can_group_admin' => 'friends',
			'group_invites_can_group_mod' => 'friends',
			'group_invites_can_group_member' => 'friends',
		) );
		unset( $GLOBALS['iaoptions'] );

		$g = $this->factory->group->create();

		$u1 = $this->factory->user->create( array(
			'role' => 'administrator',
		) );
		$this->add_user_to_group( $u1, $g );

		$u2 = $this->factory->user->create();
		$this->add_user_to_group( $u2, $g );

		$u3 = $this->factory->user->create();
		$this->add_user_to_group( $u3, $g );
		$m3 = new BP_Groups_Member( $u3, $g );
		$m3->promote( 'mod' );

		$u4 = $this->factory->user->create();
		$this->add_user_to_group( $u4, $g );
		$m4 = new BP_Groups_Member( $u4, $g );
		$m4->promote( 'admin' );

		$user = new WP_User( $u1 );

		$this->assertSame( 'friends', invite_anyone_group_invite_access_test( $g, $u1 ) );
		$this->assertSame( 'friends', invite_anyone_group_invite_access_test( $g, $u2 ) );
		$this->assertSame( 'friends', invite_anyone_group_invite_access_test( $g, $u3 ) );
		$this->assertSame( 'friends', invite_anyone_group_invite_access_test( $g, $u4 ) );

		bp_update_option( 'invite_anyone', $settings );
	}

	public function test_invite_anyone_validate_email_domain_check_should_be_case_insensitive() {
		if ( ! is_multisite() ) {
			$this->markTestSkipped( __METHOD__ . ' requires multisite.' );
		}

		update_site_option( 'limited_email_domains', array( 'foo.com' ) );

		$valid = invite_anyone_validate_email( 'Bar@FOO.COM' );

		$this->assertSame( 'okay', $valid );
	}
}

