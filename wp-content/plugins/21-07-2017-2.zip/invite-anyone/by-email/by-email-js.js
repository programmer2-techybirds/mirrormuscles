jQuery(document).ready( function() {

	var j = jQuery;

});