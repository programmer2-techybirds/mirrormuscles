<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit( 0 );
}

//nothing here
